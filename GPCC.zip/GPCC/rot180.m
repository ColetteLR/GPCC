% rotate matrix 180 degrees

function r180 = rot180(A)
r180 = rot90(A,2);
end
